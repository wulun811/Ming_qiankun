# cli_admin.py —— 0.11.9-alpha 管理命令
# 职责：cmd_admin (forget / vacuum / cleanup) / cmd_exclude (add / remove / list)
import json, os, sqlite3, sys, time
from pathlib import Path

from archiver_exclude import _load_excluded, _save_excluded


def _escape_like(s):
    return s.replace("%", "\\%").replace("_", "\\_").replace("\\", "\\\\")


def cmd_admin(args):
    """管理命令：forget / vacuum"""
    DB = Path.home() / ".ming" / "ming.db"
    HOT = Path.home() / ".ming" / "hot"

    if args.action == "forget":
        if not args.session_id:
            print("错误: 需要 --session-id 参数")
            sys.exit(1)
        if not getattr(args, "confirm", False):
            print("错误: 需要 --confirm 确认删除")
            sys.exit(1)

        if not DB.exists():
            print("数据库不存在: {}".format(DB))
            sys.exit(1)

        conn = sqlite3.connect(str(DB))
        conn.execute("PRAGMA busy_timeout=5000")
        deleted_events = conn.execute(
            "DELETE FROM events WHERE json_extract(payload, '$.layer_agent.session_id') = ?",
            (args.session_id,),
        ).rowcount

        year = time.strftime("%Y")
        tbl = f"diagnoses_{year}"
        try:
            escaped_sid = _escape_like(args.session_id)
            deleted_diagnoses = conn.execute(
                f"DELETE FROM {tbl} WHERE evidence LIKE ? ESCAPE '\\'",
                (f"%{escaped_sid}%",),
            ).rowcount
        except sqlite3.OperationalError:
            deleted_diagnoses = 0

        conn.commit()
        conn.close()

        HOT.mkdir(parents=True, exist_ok=True)
        audit_event = {
            "event_type": "__admin_action__",
            "system": "__admin__",
            "payload": {
                "action": "forget",
                "session_id": args.session_id,
                "deleted_events": deleted_events,
                "deleted_diagnoses": deleted_diagnoses,
                "operator": "cli",
                "timestamp": time.time(),
            },
            "timestamp": time.time(),
        }
        ts = time.strftime("%Y%m%d_%H%M%S")
        fp = HOT / f"__admin_action___{ts}_{os.getpid()}.jsonl"
        with open(fp, "a", encoding="utf-8") as f:
            f.write(json.dumps(audit_event, ensure_ascii=False) + "\n")

        print(f"已删除 session {args.session_id}:")
        print(f"  events: {deleted_events}")
        print(f"  diagnoses: {deleted_diagnoses}")
        print(f"  审计事件已写入: {fp}")

    elif args.action == "vacuum":
        if not DB.exists():
            print("数据库不存在: {}".format(DB))
            sys.exit(1)

        conn = sqlite3.connect(str(DB))
        conn.execute("PRAGMA busy_timeout=5000")
        before = DB.stat().st_size
        conn.execute("VACUUM")
        conn.close()
        after = DB.stat().st_size

        HOT.mkdir(parents=True, exist_ok=True)
        audit_event = {
            "event_type": "__vacuum__",
            "system": "__admin__",
            "payload": {
                "action": "vacuum",
                "before_size_mb": round(before / (1024 * 1024), 2),
                "after_size_mb": round(after / (1024 * 1024), 2),
                "operator": "cli",
                "timestamp": time.time(),
            },
            "timestamp": time.time(),
        }
        ts = time.strftime("%Y%m%d_%H%M%S")
        fp = HOT / f"__vacuum___{ts}_{os.getpid()}.jsonl"
        with open(fp, "a", encoding="utf-8") as f:
            f.write(json.dumps(audit_event, ensure_ascii=False) + "\n")

        print("VACUUM 完成:")
        print(f"  前: {before / (1024 * 1024):.2f} MB")
        print(f"  后: {after / (1024 * 1024):.2f} MB")
        print(f"  释放: {(before - after) / (1024 * 1024):.2f} MB")
        print(f"  审计事件已写入: {fp}")

    elif args.action == "cleanup":
        if not DB.exists():
            print("数据库不存在: {}".format(DB))
            sys.exit(1)

        conn = sqlite3.connect(str(DB))
        conn.execute("PRAGMA busy_timeout=5000")
        cleaned_events = 0
        cleaned_dx = 0
        for sys_name in ("unknown", "__admin__"):
            de = conn.execute(
                "DELETE FROM events WHERE system = ?", (sys_name,)
            ).rowcount
            cleaned_events += de
            year = time.strftime("%Y")
            tbl = f"diagnoses_{year}"
            try:
                dd = conn.execute(
                    f"DELETE FROM {tbl} WHERE system = ?", (sys_name,)
                ).rowcount
                cleaned_dx += dd
            except sqlite3.OperationalError:
                pass
        conn.commit()
        conn.execute("PRAGMA optimize")
        conn.close()

        HOT.mkdir(parents=True, exist_ok=True)
        audit_event = {
            "event_type": "__cleanup__",
            "system": "__admin__",
            "payload": {
                "action": "cleanup",
                "cleaned_events": cleaned_events,
                "cleaned_diagnoses": cleaned_dx,
                "operator": "cli",
                "timestamp": time.time(),
            },
            "timestamp": time.time(),
        }
        ts = time.strftime("%Y%m%d_%H%M%S")
        fp = HOT / f"__cleanup___{ts}_{os.getpid()}.jsonl"
        with open(fp, "a", encoding="utf-8") as f:
            f.write(json.dumps(audit_event, ensure_ascii=False) + "\n")

        print("清理完成:")
        print(f"  events: {cleaned_events}")
        print(f"  diagnoses: {cleaned_dx}")


def cmd_exclude(args):
    """停止/恢复观察某个实例：add / remove / list"""
    excluded = _load_excluded()

    if args.action == "list":
        if excluded:
            print("已排除的实例:")
            for s in sorted(excluded):
                print(f"  {s}")
        else:
            print("没有排除任何实例")
        return

    if not args.system:
        print("错误: 需要指定实例名称")
        sys.exit(1)

    if args.action == "add":
        if args.system in excluded:
            print(f"实例 {args.system} 已在排除列表中")
            return
        excluded.add(args.system)
        _save_excluded(excluded)
        print(f"已停止观察 {args.system}")
        print(f"当前排除列表: {', '.join(sorted(excluded))}")

    elif args.action == "remove":
        if args.system not in excluded:
            print(f"实例 {args.system} 不在排除列表中")
            return
        excluded.discard(args.system)
        _save_excluded(excluded)
        print(f"已恢复观察 {args.system}")
        if excluded:
            print(f"当前排除列表: {', '.join(sorted(excluded))}")
        else:
            print("排除列表已清空")
