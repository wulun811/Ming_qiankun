// probe_go.go —— v0.9.3 乾坤镜 Go 探针
// 职责：纯粹的无状态热轨写入器，零数据库依赖，零第三方依赖
// 依赖：Go 标准库 only (os, path/filepath, encoding/json, sync, time, fmt)
// 禁止：任何网络通信、任何第三方包

package probe

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

const (
	DiskMinMB         = 500
	SchemaVersion     = "0.9.3"
	BatchSize         = 10
	FlushIntervalMs   = 200
	DiskCheckInterval = 5 * time.Second
)

var requiredLayers = map[string][]string{
	"llm_invoke":      {"layer_agent", "layer_llm", "layer_network"},
	"tool_call":       {"layer_agent", "layer_tool", "layer_network"},
	"memory_retrieve": {"layer_agent", "layer_memory"},
	"agent_step":      {"layer_agent"},
	"error":           {"layer_agent"},
}

type Event struct {
	System         string                 `json:"system"`
	Mode           string                 `json:"mode"`
	EventType      string                 `json:"event_type"`
	Payload        map[string]interface{} `json:"payload"`
	Timestamp      float64                `json:"timestamp"`
	MonotonicMs    float64                `json:"monotonic_ms"`
	Lamport        int                    `json:"lamport"`
	Pid            int                    `json:"_pid"`
	SchemaVersion  string                 `json:"_schema_version"`
}

type Probe struct {
	mu            sync.Mutex
	system        string
	mode          string
	pid           int
	baseIntegrity float64
	hotDir        string
	batch         []Event
	lastFlush     time.Time
	lastDiskCheck time.Time
	diskFreeMb    float64
	lamport       int
	selfErrors    []string
	stopCh        chan struct{}
	pausedUntil   time.Time
}

func New(system, mode string) *Probe {
	if mode == "" {
		mode = "white"
	}
	p := &Probe{
		system:        system,
		mode:          mode,
		pid:           os.Getpid(),
		baseIntegrity: 1.0,
		lastFlush:     time.Now(),
		diskFreeMb:    9999,
		stopCh:        make(chan struct{}),
	}
	if mode == "black" {
		p.baseIntegrity = 0.6
	}

	// 初始化 hot 目录
	home, _ := os.UserHomeDir()
	p.hotDir = filepath.Join(home, ".ming", "hot")
	if err := os.MkdirAll(p.hotDir, 0755); err != nil {
		p.hotDir = filepath.Join(os.TempDir(), "ming_fallback")
		os.MkdirAll(p.hotDir, 0755)
		p.selfErrors = append(p.selfErrors, "hot_dir_fallback_to_tmp")
	}

	// 注册 + 启动定时 flush
	p.emit("__register__", map[string]interface{}{
		"pid":            p.pid,
		"mode":           p.mode,
		"schema_version": SchemaVersion,
		"registered_at":  float64(time.Now().UnixMilli()) / 1000,
		"_base_integrity": p.baseIntegrity,
	})

	go func() {
		ticker := time.NewTicker(FlushIntervalMs * time.Millisecond)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				p.Flush()
			case <-p.stopCh:
				return
			}
		}
	}()

	return p
}

func (p *Probe) validateLayers(eventType string, payload map[string]interface{}) {
	required, ok := requiredLayers[eventType]
	if !ok {
		return
	}
	var missing []string
	for _, l := range required {
		if _, exists := payload[l]; !exists {
			missing = append(missing, l)
		}
	}
	if len(missing) > 0 {
		payload["_incomplete"] = missing
		payload["_integrity_hint"] = "partial"
	}
}

func (p *Probe) isPaused() bool {
	now := time.Now()
	if now.Before(p.pausedUntil) {
		return true
	}
	pausedFile := filepath.Join(os.Getenv("HOME"), ".ming", ".paused", p.system)
	if _, err := os.Stat(pausedFile); err == nil {
		p.pausedUntil = now.Add(5 * time.Second)
		return true
	}
	p.pausedUntil = time.Time{}
	return false
}

func (p *Probe) Emit(eventType string, payload map[string]interface{}) {
	if p.isPaused() {
		return
	}
	p.mu.Lock()
	defer p.mu.Unlock()

	p.validateLayers(eventType, payload)

	if p.mode == "black" {
		payload["_base_integrity"] = 0.6
	}

	ev := Event{
		System:        p.system,
		Mode:          p.mode,
		EventType:     eventType,
		Payload:       payload,
		Timestamp:     float64(time.Now().UnixMilli()) / 1000,
		MonotonicMs:   float64(time.Now().UnixMilli()),
		Pid:           p.pid,
		SchemaVersion: SchemaVersion,
	}
	p.batch = append(p.batch, ev)

	if len(p.batch) >= BatchSize {
		p.flushLocked()
	}
}

func (p *Probe) Flush() {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.flushLocked()
}

func (p *Probe) flushLocked() {
	if len(p.batch) == 0 {
		return
	}

	now := time.Now()
	if now.Sub(p.lastDiskCheck) > DiskCheckInterval {
		var stat os.Statfs_t
		if err := os.Statfs(p.hotDir, &stat); err == nil {
			p.diskFreeMb = float64(stat.Bavail*uint64(stat.Bsize)) / (1024 * 1024)
		} else {
			p.diskFreeMb = -1
		}
		p.lastDiskCheck = now
	}

	if p.diskFreeMb < DiskMinMB {
		filtered := make([]Event, 0, len(p.batch))
		for _, ev := range p.batch {
			if ev.EventType == "error" || len(ev.EventType) >= 2 && ev.EventType[:2] == "__" {
				filtered = append(filtered, ev)
			}
		}
		p.batch = filtered
		if len(p.batch) == 0 {
			return
		}
	}

	for i := range p.batch {
		p.lamport++
		p.batch[i].Lamport = p.lamport
	}

	ts := now.Format("20060102_150405")
	filepath := filepath.Join(p.hotDir, fmt.Sprintf("%s_%s_%d.jsonl", p.system, ts, p.pid))

	f, err := os.OpenFile(filepath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		p.selfErrors = append(p.selfErrors, err.Error())
		fmt.Fprintf(os.Stderr, "[MING-DROP] %v\n", err)
		p.batch = nil
		return
	}
	defer f.Close()

	for _, ev := range p.batch {
		data, _ := json.Marshal(ev)
		f.Write(data)
		f.Write([]byte{'\n'})
	}

	p.batch = nil
	p.lastFlush = time.Now()
}

func (p *Probe) Expect(eventType string, withinSeconds int) {
	p.Emit("__expect__", map[string]interface{}{
		"expected_event": eventType,
		"deadline":       float64(time.Now().UnixMilli())/1000 + float64(withinSeconds),
		"fulfilled":      false,
	})
}

func (p *Probe) Fulfill(eventType string) {
	p.Emit("__fulfill__", map[string]interface{}{"expected_event": eventType})
}

func (p *Probe) Touch() {
	p.Emit("__touch__", map[string]interface{}{"pid": p.pid})
}

func (p *Probe) Health() {
	p.Emit("__health__", map[string]interface{}{
		"emit_success_count_1m": len(p.batch),
		"emit_drop_count_1m":    0,
		"last_errors":           p.selfErrors,
		"disk_free_mb":          p.diskFreeMb,
		"buffer_queue_size":     len(p.batch),
	})
}

func (p *Probe) Close() {
	close(p.stopCh)
	p.Flush()
}
