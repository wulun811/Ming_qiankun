# probe_autogpt.py —— v0.11.9-alpha 乾坤镜 AutoGPT 适配层
# 职责：在 AutoGPT 多 Agent 工作流中注入乾坤镜探针调用
# 依赖：_python_base.py, _payload_builders.py（零第三方依赖）

from adapters._python_base import make_adapter_init, instrumented
from adapters._payload_builders import (
    build_llm_event,
    build_llm_output_event,
    build_step_event,
    build_step_start_event,
    build_step_finish_event,
    _extract_tokens,
    _extract_finish_reason,
)
import os


def _get_content_max_len():
    val = os.environ.get("MING_CONTENT_MAX_LEN")
    if val is None:
        return 2000
    try:
        v = int(val)
        return 0 if v == 0 else v
    except ValueError:
        return 2000


def truncate(s, max_len=None):
    if max_len is None:
        max_len = _get_content_max_len()
    if max_len == 0:
        return s
    if s and len(s) > max_len:
        return s[:max_len] + f"...[truncated {len(s) - max_len} chars]"
    return s


def _monkey_patch(probe):
    try:
        from autogpt.agent.agent import Agent

        original_step = Agent.step

        def patched_step(self, *args, **kwargs):
            probe.emit(
                "agent_step_start",
                build_step_start_event(
                    step_id="step",
                    session_id=getattr(self, "session_id", None),
                    agent_name=getattr(self, "name", None) or "autogpt",
                    target_host="local",
                ),
            )
            try:
                result = original_step(self, *args, **kwargs)
                probe.emit(
                    "agent_step_finish",
                    build_step_finish_event(
                        step_id="step",
                        session_id=getattr(self, "session_id", None),
                        agent_name=getattr(self, "name", None) or "autogpt",
                        target_host="local",
                    ),
                )
                return result
            except Exception:
                probe.emit(
                    "agent_step_finish",
                    build_step_finish_event(
                        step_id="step",
                        session_id=getattr(self, "session_id", None),
                        agent_name=getattr(self, "name", None) or "autogpt",
                        target_host="local",
                    ),
                )
                raise

        Agent.step = patched_step

        from autogpt.llm.api_manager import ApiManager

        original_create = ApiManager.create_chat_completion

        def patched_create(self, *args, **kwargs):
            # 发射 llm_invoke 事件（原有逻辑）
            import time

            start = time.time()
            result = original_create(self, *args, **kwargs)
            latency_ms = (time.time() - start) * 1000

            probe.emit(
                "llm_invoke",
                build_llm_event(
                    step_id="llm",
                    agent_name="autogpt",
                    model=kwargs.get("model"),
                    latency_ms=latency_ms,
                    response=result,
                    kwargs={
                        "input_tokens": kwargs.get("input_tokens"),
                        "output_tokens": kwargs.get("output_tokens"),
                        "finish_reason": _extract_finish_reason(result, kwargs),
                    },
                    target_host="api.openai.com",
                ),
            )

            # 发射 llm_output 事件
            output_text = None
            if result:
                if isinstance(result, dict):
                    choices = result.get("choices", [])
                    if choices and len(choices) > 0:
                        message = choices[0].get("message", {})
                        output_text = message.get("content")
                elif hasattr(result, "choices"):
                    try:
                        output_text = result.choices[0].message.content
                    except (IndexError, AttributeError):
                        pass

            if output_text:
                probe.emit(
                    "llm_output",
                    build_llm_output_event(
                        step_id="llm",
                        agent_name="autogpt",
                        output_text=truncate(output_text),
                        target_host="api.openai.com",
                    ),
                )
            return result

        ApiManager.create_chat_completion = patched_create

    except ImportError:
        pass


init_autogpt_probe = make_adapter_init(_monkey_patch, "autogpt")
