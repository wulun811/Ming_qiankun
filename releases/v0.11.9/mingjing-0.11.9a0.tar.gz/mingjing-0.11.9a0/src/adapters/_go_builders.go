// _go_builders.go —— v0.9.3 乾坤镜 Go 适配器事件构建器
// 职责：提供纯函数构建事件 payload，消除适配器间重复代码
// 归属：官方参考实现内部工具，非协议标准

package probe

func BuildLLMEvent(stepID, sessionID, agentName, model string, latencyMs float64, inputTokens, outputTokens int) map[string]interface{} {
	return map[string]interface{}{
		"layer_agent": map[string]string{"step_id": stepID, "session_id": sessionID, "agent_name": agentName},
		"layer_llm": map[string]interface{}{
			"model": model, "input_tokens": inputTokens, "output_tokens": outputTokens,
			"latency_ms": latencyMs, "cache_hit": false,
		},
		"layer_network": map[string]interface{}{"target_host": "llm_api", "status_code": 200},
	}
}

func BuildToolEvent(stepID, sessionID, agentName, toolName string, executionMs float64, args map[string]interface{}, result string) map[string]interface{} {
	r := result
	if len(r) > 500 {
		r = r[:500]
	}
	return map[string]interface{}{
		"layer_agent": map[string]string{"step_id": stepID, "session_id": sessionID, "agent_name": agentName},
		"layer_tool": map[string]interface{}{
			"tool_name": toolName, "tool_args": args, "tool_result": r, "execution_ms": executionMs,
		},
		"layer_network": map[string]interface{}{"target_host": "local", "status_code": 200},
	}
}

func BuildMemoryEvent(stepID, sessionID, agentName, memoryType string, latencyMs float64, query string, resultsCount int) map[string]interface{} {
	q := query
	if len(q) > 200 {
		q = q[:200]
	}
	return map[string]interface{}{
		"layer_agent": map[string]string{"step_id": stepID, "session_id": sessionID, "agent_name": agentName},
		"layer_memory": map[string]interface{}{
			"memory_type": memoryType, "query": q, "results_count": resultsCount, "latency_ms": latencyMs,
		},
	}
}

func BuildStepEvent(stepID, sessionID, agentName string, extras map[string]string) map[string]interface{} {
	agent := map[string]string{"step_id": stepID, "session_id": sessionID, "agent_name": agentName}
	for k, v := range extras {
		agent[k] = v
	}
	return map[string]interface{}{"layer_agent": agent}
}

func BuildErrorEvent(stepID, sessionID, agentName, errorType, errorMsg string) map[string]interface{} {
	return map[string]interface{}{
		"layer_agent": map[string]string{"step_id": stepID, "session_id": sessionID, "agent_name": agentName},
		"error_type":  errorType, "error_msg": errorMsg,
	}
}
