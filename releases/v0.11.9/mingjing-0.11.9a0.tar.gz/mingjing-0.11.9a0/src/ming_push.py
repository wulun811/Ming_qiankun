# ming_push.py —— v0.11.9-alpha P0 诊断秒级推送
# 职责：分诊后 P0 命中 → HTTP POST 到土行孙 gateway
# 依赖：标准库 only（urllib）
import urllib.request, json, time, logging, socket
from pathlib import Path

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 9002
DEFAULT_PATH = "/ming/push"
TIMEOUT = 5

_log = logging.getLogger("ming.push")


def _is_gateway_alive(host, port, timeout=1):
    """TCP 探活：土行孙 gateway 是否在监听"""
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        sock.close()
        return True
    except (OSError, socket.timeout):
        return False


def push_p0(diagnoses: list, host=DEFAULT_HOST, port=DEFAULT_PORT, path=DEFAULT_PATH):
    """将 P0 诊断逐个推送到土行孙 gateway，失败静默"""
    if not diagnoses:
        return
    if not _is_gateway_alive(host, port):
        return

    from credential_vault import get_secret

    token = get_secret("tusunsun.pushToken")
    url = f"http://{host}:{port}{path}"
    results = []

    for d in diagnoses:
        payload = {
            "type": "ming.diagnosis",
            "version": "0.7",
            "diagnosis": {
                "fault_id": d.get("fault_id", ""),
                "name": d.get("name", ""),
                "severity": "P0",
                "system": d.get("system", "unknown"),
                "count": d.get("count", 1),
                "session_id": d.get("session_id", ""),
                "confidence": d.get("confidence", 0.9),
                "evidence": d.get("evidence", ""),
                "window_s": d.get("window_s", 300),
            },
            "action": {
                "recommended": d.get("action", "alert"),
                "reason": d.get("evidence", ""),
            },
        }

        headers = {
            "Content-Type": "application/json",
            "X-Ming-Version": "0.11.9-alpha",
        }
        if token:
            headers["X-Ming-Token"] = token

        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        try:
            req = urllib.request.Request(url, data=data, headers=headers)
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                _log.info(
                    "P0 push OK: %s → %s (%d)", d.get("fault_id"), url, resp.status
                )
                results.append(body)
        except Exception as e:
            _log.warning("P0 push failed (%s): %s", d.get("fault_id", ""), e)

    return results if results else None
