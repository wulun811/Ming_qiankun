# cli_replay.py —— 0.11.9-alpha 诊断回放时间线命令
# 职责：按时间线展现事件→诊断演化过程，辅助故障排查
import sqlite3, json, time, re, sys
from pathlib import Path

DB = Path.home() / ".ming" / "ming.db"

_SEV_COLOR = {"P0": "\033[91m", "P1": "\033[93m", "P2": "\033[92m", "META": "\033[94m"}
_RESET = "\033[0m"


def _parse_duration(s):
    """解析 '30m' / '2h' / '1d' / 浮点时间戳"""
    if not s:
        return time.time() - 3600
    try:
        return float(s)
    except ValueError:
        pass
    seconds = 0
    for m in re.finditer(r"(\d+)([smhd])", s.lower()):
        n = int(m.group(1))
        u = m.group(2)
        if u == "s":
            seconds += n
        elif u == "m":
            seconds += n * 60
        elif u == "h":
            seconds += n * 3600
        elif u == "d":
            seconds += n * 86400
    return seconds if seconds > 0 else 3600


def _ts_str(ts):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))


def _ts_clock(ts):
    return time.strftime("%H:%M:%S", time.localtime(ts))


def cmd_replay(args):
    system = getattr(args, "system", None)
    since_raw = getattr(args, "since", "1h")
    until_raw = getattr(args, "until", None)
    detail_level = getattr(args, "detail", "normal")

    if not system:
        print(
            "用法: ming replay --system <name> [--since 1h] [--until 1h] [--detail full]"
        )
        print("")
        print("选项:")
        print("  --system    系统名称 (必需)")
        print("  --since     起始时间, 支持 '30m'/'2h'/'1d' 或 Unix 时间戳 (默认 1h)")
        print("  --until     结束时间, 同上 (默认 now)")
        print("  --detail    详细程度: normal | full (默认 normal)")
        print("")
        print("示例:")
        print("  ming replay --system openclaw --since 2h")
        print("  ming replay --system openclaw --since 1714700000 --until 1714800000")
        return

    now = time.time()
    since = (
        now - _parse_duration(since_raw)
        if isinstance(since_raw, str)
        else float(since_raw)
    )
    if until_raw:
        if isinstance(until_raw, str):
            until = now - _parse_duration(until_raw)
        else:
            until = float(until_raw)
    else:
        until = now

    if not DB.exists():
        print(f"数据库不存在: {DB}")
        return

    conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    conn.execute("PRAGMA busy_timeout=5000")
    conn.row_factory = sqlite3.Row
    try:
        # === 查询事件时间线 ===
        ev_rows = conn.execute(
            """SELECT id, system, event_type, timestamp, payload, lamport, monotonic_ms, curr_hash
               FROM events
               WHERE system = ? AND timestamp >= ? AND timestamp <= ?
               ORDER BY timestamp ASC, lamport ASC""",
            (system, since, until),
        ).fetchall()

        events = []
        for r in ev_rows:
            d = dict(r)
            try:
                pl = json.loads(d.get("payload", "{}"))
            except (json.JSONDecodeError, TypeError):
                pl = {}
            events.append(
                {
                    "id": d["id"],
                    "ts": d["timestamp"],
                    "type": d["event_type"],
                    "payload": pl if detail_level == "full" else {},
                    "lamport": d.get("lamport"),
                    "hash": (d.get("curr_hash", "") or "")[:8],
                }
            )

        # === 查询诊断时间线 ===
        year = time.strftime("%Y")
        tbl = f"diagnoses_{year}"
        dx_rows = []
        try:
            dx_rows = conn.execute(
                f"""SELECT diagnosis_id, system, fault_id, diagnosis_name,
                           confidence, severity, evidence, evidence_quality,
                           status, created_at
                    FROM {tbl}
                    WHERE system = ? AND created_at >= ? AND created_at <= ?
                    ORDER BY created_at ASC""",
                (system, since, until),
            ).fetchall()
        except sqlite3.OperationalError:
            pass

        diagnoses = []
        for r in dx_rows:
            d = dict(r)
            try:
                ev = json.loads(d.get("evidence", "[]"))
            except (json.JSONDecodeError, TypeError):
                ev = []
            diagnoses.append(
                {
                    "id": d["diagnosis_id"],
                    "ts": d["created_at"],
                    "fault_id": d["fault_id"],
                    "name": d["diagnosis_name"],
                    "confidence": d["confidence"],
                    "severity": d["severity"],
                    "quality": d.get("evidence_quality", 0),
                    "status": d["status"],
                    "evidence": ev if detail_level == "full" else [],
                }
            )

        # === 合并时间线 ===
        timeline = []

        # 事件 → 标记为 'E'
        for ev in events:
            timeline.append({"ts": ev["ts"], "kind": "event", "data": ev})

        # 诊断 → 标记为 'D'
        for dx in diagnoses:
            timeline.append({"ts": dx["ts"], "kind": "diagnosis", "data": dx})

        timeline.sort(key=lambda x: (x["ts"], 0 if x["kind"] == "event" else 1))

        # === 输出 ===
        if getattr(args, "json", False):
            out = {
                "system": system,
                "since": since,
                "until": until,
                "since_str": _ts_str(since),
                "until_str": _ts_str(until),
                "event_count": len(events),
                "diagnosis_count": len(diagnoses),
                "timeline": timeline,
            }
            print(json.dumps(out, indent=2, ensure_ascii=False, default=str))
            return

        # === 人类可读时间线 ===
        window_label = (
            _ts_str(since) if (until - since) > 7200 else f"{(until - since) / 60:.0f}m"
        )
        print(f"╔══════════════════════════════════════════════════════════╗")
        print(
            f"║  诊断回放 ── {system} ── {window_label} ({len(events)} 事件 + {len(diagnoses)} 诊断) ║"
        )
        print(f"╚══════════════════════════════════════════════════════════╝")
        print()

        if not events and not diagnoses:
            print(f"  (无数据)  {_ts_str(since)} → {_ts_str(until)}")
            return

        # track what we've already shown for grouping repeated timeline items
        last_ts = 0
        for item in timeline:
            ts = item["ts"]
            indent = "  "
            if ts - last_ts > 10:
                if last_ts > 0:
                    gap = ts - last_ts
                    if gap > 60:
                        print(f"\033[90m  ... {gap:.0f}s 静默 ...\033[0m")
                last_ts = ts

            time_str = _ts_clock(ts)
            if item["kind"] == "event":
                d = item["data"]
                print(f"{indent}\033[90m{time_str}\033[0m [事件] {d['type']}")
                if detail_level == "full" and d.get("payload"):
                    pl_keys = list(d["payload"].keys())
                    if pl_keys:
                        summary = ", ".join(
                            f"{k}={d['payload'][k]}" for k in sorted(pl_keys)[:5]
                        )
                        if len(pl_keys) > 5:
                            summary += f" ...(+{len(pl_keys) - 5})"
                        print(f"{indent}        \033[90m{summary}\033[0m")
                if d.get("hash"):
                    print(f"{indent}        hash:{d['hash']}")

            elif item["kind"] == "diagnosis":
                d = item["data"]
                sev = d["severity"]
                color = _SEV_COLOR.get(sev, "")
                quality_star = "★" * d["quality"]
                status_tag = " ✓" if d["status"] == "cross_validated" else ""

                print(
                    f"{indent}{time_str} {color}[{sev}] {d['fault_id']} {d['name']}{_RESET}"
                )
                print(
                    f"{indent}        置信度:{d['confidence']:.0%}  证据质量:{quality_star}{status_tag}"
                )

                if detail_level == "full" and d.get("evidence"):
                    for ei, ev_piece in enumerate(d["evidence"][:3]):
                        summary = ev_piece.get("summary", "")
                        kf = ev_piece.get("key_fields", {})
                        kf_str = ", ".join(
                            f"{k}={v}"
                            for k, v in sorted(kf.items())
                            if k != "_semantic_note"
                        )[:80]
                        print(
                            f"{indent}        E{ei}: {summary} \033[90m|{kf_str}\033[0m"
                        )
                    if len(d["evidence"]) > 3:
                        print(
                            f"{indent}        ... 还有 {len(d['evidence']) - 3} 条证据"
                        )

            last_ts = ts

        print()
        total_events = len(events)
        total_dx = len(diagnoses)
        p0_dx = sum(1 for d in diagnoses if d["severity"] == "P0")
        p1_dx = sum(1 for d in diagnoses if d["severity"] == "P1")
        print(
            f"总计: \033[94m{total_events}\033[0m 事件  "
            f"\033[91m{p0_dx}\033[0m P0  \033[93m{p1_dx}\033[0m P1  "
            f"\033[92m{total_dx - p0_dx - p1_dx}\033[0m P2/META"
        )

    finally:
        conn.close()
