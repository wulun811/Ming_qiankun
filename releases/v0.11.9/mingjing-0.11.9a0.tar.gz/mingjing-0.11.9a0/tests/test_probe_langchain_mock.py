# test_probe_langchain_mock.py —— 乾坤镜 LangChain 适配器 Mock 测试
# 兼容 langchain-core >= 1.0，patch invoke 入口

import sys
import types
import unittest
from pathlib import Path

_src = Path(__file__).parent.parent / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

_captured_events = []


def _setup_langchain_modules():
    class FakeAIMessage:
        def __init__(self):
            self.content = "Hello!"
            self.response_metadata = {
                "token_usage": {"prompt_tokens": 10, "completion_tokens": 5},
                "finish_reason": "stop",
            }
            self.usage_metadata = {
                "input_tokens": 10,
                "output_tokens": 5,
                "total_tokens": 15,
                "input_token_details": {"cache_read": 0},
            }

    class FakeBaseChatModel:
        def invoke(self, input, *args, **kwargs):
            return FakeAIMessage()

    class FakeBaseLLM:
        def invoke(self, input, *args, **kwargs):
            return "LLM response"

    class FakeBaseTool:
        name: str = "test_tool"
        description: str = "A test tool"

        def invoke(self, input, *args, **kwargs):
            return "tool_result"

    class FakeDocument:
        def __init__(self):
            self.id = "chunk_001"
            self.page_content = "doc1"
            self.metadata = {"score": 0.85}

    class FakeBaseRetriever:
        def invoke(self, input, *args, **kwargs):
            return [FakeDocument()]

    class FakeRunnable:
        name = "test_runnable"

        def invoke(self, input, *args, **kwargs):
            return {"result": "ok"}

    class FakeRunnableSequence:
        name = None

        def invoke(self, input, *args, **kwargs):
            return {"result": "chain_ok"}

    fake_lc_chat = types.ModuleType("langchain_core.language_models.chat_models")
    fake_lc_chat.BaseChatModel = FakeBaseChatModel

    fake_lc_llms = types.ModuleType("langchain_core.language_models.llms")
    fake_lc_llms.BaseLLM = FakeBaseLLM

    fake_lc_tools = types.ModuleType("langchain_core.tools")
    fake_lc_tools.BaseTool = FakeBaseTool

    fake_lc_retrievers = types.ModuleType("langchain_core.retrievers")
    fake_lc_retrievers.BaseRetriever = FakeBaseRetriever

    fake_lc_runnables = types.ModuleType("langchain_core.runnables")
    fake_lc_runnables.Runnable = FakeRunnable
    fake_lc_runnables.RunnableSequence = FakeRunnableSequence

    sys.modules["langchain_core.language_models.chat_models"] = fake_lc_chat
    sys.modules["langchain_core.language_models.llms"] = fake_lc_llms
    sys.modules["langchain_core.tools"] = fake_lc_tools
    sys.modules["langchain_core.retrievers"] = fake_lc_retrievers
    sys.modules["langchain_core.runnables"] = fake_lc_runnables


class TestLangChainAdapter(unittest.TestCase):
    def setUp(self):
        global _captured_events
        _captured_events.clear()
        _setup_langchain_modules()
        from probe_uni import ProbeUni

        self._orig_emit = ProbeUni.emit

        def capture_emit(self, event_type, payload):
            _captured_events.append({"event_type": event_type, "payload": payload})

        ProbeUni.emit = capture_emit

    def tearDown(self):
        from probe_uni import ProbeUni

        ProbeUni.emit = self._orig_emit
        for mod in list(sys.modules.keys()):
            if mod.startswith("langchain"):
                del sys.modules[mod]

    def test_adapter_imports_without_error(self):
        from adapters.probe_langchain import init_langchain_probe

        self.assertTrue(callable(init_langchain_probe))

    def test_monkey_patch_applies_to_chat_invoke(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.language_models.chat_models import BaseChatModel

        self.assertNotEqual(BaseChatModel.invoke.__name__, "invoke")

    def test_monkey_patch_applies_to_llm_invoke(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.language_models.llms import BaseLLM

        self.assertNotEqual(BaseLLM.invoke.__name__, "invoke")

    def test_emit_on_chat_invoke(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.language_models.chat_models import BaseChatModel

        llm = BaseChatModel()
        llm.invoke("test prompt")
        events = [e for e in _captured_events if e["event_type"] == "llm_invoke"]
        self.assertTrue(len(events) > 0)
        self.assertIn("layer_llm", events[0]["payload"])
        self.assertIn("layer_agent", events[0]["payload"])

    def test_llm_invoke_has_cache_hit_field(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.language_models.chat_models import BaseChatModel

        llm = BaseChatModel()
        llm.invoke("test prompt")
        events = [e for e in _captured_events if e["event_type"] == "llm_invoke"]
        self.assertTrue(len(events) > 0)
        self.assertIn("cache_hit", events[0]["payload"]["layer_llm"])

    def test_emit_on_llm_output(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.language_models.chat_models import BaseChatModel

        llm = BaseChatModel()
        llm.invoke("test prompt")
        events = [e for e in _captured_events if e["event_type"] == "llm_output"]
        self.assertTrue(len(events) > 0)
        self.assertIn("output_text", events[0]["payload"]["layer_llm"])
        self.assertIn("output_text_hash", events[0]["payload"]["layer_llm"])

    def test_emit_on_tool_invoke(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.tools import BaseTool

        tool = BaseTool()
        tool.invoke("test")
        events = [e for e in _captured_events if e["event_type"] == "tool_call"]
        self.assertTrue(len(events) > 0)
        self.assertIn("layer_tool", events[0]["payload"])

    def test_emit_on_retriever_invoke(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.retrievers import BaseRetriever

        retriever = BaseRetriever()
        retriever.invoke("test query")
        events = [e for e in _captured_events if e["event_type"] == "memory_retrieve"]
        self.assertTrue(len(events) > 0)
        self.assertIn("layer_memory", events[0]["payload"])

    def test_retriever_emits_chunk_id_and_relevance(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.retrievers import BaseRetriever

        retriever = BaseRetriever()
        retriever.invoke("test query")
        events = [e for e in _captured_events if e["event_type"] == "memory_retrieve"]
        self.assertTrue(len(events) > 0)
        mem = events[0]["payload"]["layer_memory"]
        self.assertEqual(mem["chunk_id"], "chunk_001")
        self.assertEqual(mem["relevance_score"], 0.85)

    def test_emit_on_runnable_invoke(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.runnables import Runnable

        runnable = Runnable()
        runnable.invoke({"input": "test"})
        start_events = [
            e for e in _captured_events if e["event_type"] == "agent_step_start"
        ]
        finish_events = [
            e for e in _captured_events if e["event_type"] == "agent_step_finish"
        ]
        self.assertTrue(len(start_events) > 0)
        self.assertTrue(len(finish_events) > 0)

    def test_emit_on_runnable_sequence_invoke(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.runnables import RunnableSequence

        chain = RunnableSequence()
        chain.invoke({"input": "test"})
        seq_events = [
            e for e in _captured_events if e["event_type"] == "agent_step_start"
        ]
        self.assertTrue(len(seq_events) > 0)
        self.assertIn(
            "RunnableSequence", seq_events[0]["payload"]["layer_agent"]["step_id"]
        )

    def test_agent_step_unified_event_emitted(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.runnables import Runnable

        runnable = Runnable()
        runnable.invoke({"input": "test"})
        step_events = [e for e in _captured_events if e["event_type"] == "agent_step"]
        self.assertTrue(len(step_events) > 0)
        self.assertIn("decision_summary", step_events[0]["payload"]["layer_agent"])

    def test_session_id_extraction(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.language_models.chat_models import BaseChatModel

        llm = BaseChatModel()
        llm.invoke("test prompt", config={"configurable": {"session_id": "sess_123"}})
        events = [e for e in _captured_events if e["event_type"] == "llm_invoke"]
        self.assertTrue(len(events) > 0)
        self.assertEqual(events[0]["payload"]["layer_agent"]["session_id"], "sess_123")

    def test_thread_id_fallback(self):
        from adapters.probe_langchain import init_langchain_probe

        init_langchain_probe()
        from langchain_core.language_models.chat_models import BaseChatModel

        llm = BaseChatModel()
        llm.invoke("test prompt", config={"configurable": {"thread_id": "thread_456"}})
        events = [e for e in _captured_events if e["event_type"] == "llm_invoke"]
        self.assertTrue(len(events) > 0)
        self.assertEqual(
            events[0]["payload"]["layer_agent"]["session_id"], "thread_456"
        )


if __name__ == "__main__":
    unittest.main()
