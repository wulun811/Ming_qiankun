# test_probe_openhands_mock.py —— 乾坤镜 OpenHands 适配器 Mock 测试

import sys
import types
import unittest
from pathlib import Path

_src = Path(__file__).parent.parent / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

_captured_events = []


def _setup_openhands_modules():
    class FakeAgentController:
        def __init__(self):
            self.sid = "test_session"

        def step(self, *args, **kwargs):
            return {"action": "done"}

    class FakeLLM:
        def __init__(self):
            self.model = "gpt-4"

        def completion(self, *args, **kwargs):
            return {"choices": [{"message": {"content": "ok"}}]}

    class FakeRuntime:
        def run(self, command, *args, **kwargs):
            return "output"

    fake_controller = types.ModuleType("openhands.controller")
    fake_controller.agent_controller = types.ModuleType(
        "openhands.controller.agent_controller"
    )
    fake_controller.agent_controller.AgentController = FakeAgentController
    fake_llm = types.ModuleType("openhands.llm")
    fake_llm.llm = types.ModuleType("openhands.llm.llm")
    fake_llm.llm.LLM = FakeLLM
    fake_runtime = types.ModuleType("openhands.runtime")
    fake_runtime.base = types.ModuleType("openhands.runtime.base")
    fake_runtime.base.Runtime = FakeRuntime

    sys.modules["openhands"] = types.ModuleType("openhands")
    sys.modules["openhands.controller"] = fake_controller
    sys.modules["openhands.controller.agent_controller"] = (
        fake_controller.agent_controller
    )
    sys.modules["openhands.llm"] = fake_llm
    sys.modules["openhands.llm.llm"] = fake_llm.llm
    sys.modules["openhands.runtime"] = fake_runtime
    sys.modules["openhands.runtime.base"] = fake_runtime.base


class TestOpenHandsAdapter(unittest.TestCase):
    def setUp(self):
        global _captured_events
        _captured_events.clear()
        _setup_openhands_modules()
        from probe_uni import ProbeUni

        self._orig_emit = ProbeUni.emit

        def capture_emit(self, event_type, payload):
            _captured_events.append({"event_type": event_type, "payload": payload})

        ProbeUni.emit = capture_emit

    def tearDown(self):
        from probe_uni import ProbeUni

        ProbeUni.emit = self._orig_emit
        for mod in list(sys.modules.keys()):
            if mod.startswith("openhands"):
                del sys.modules[mod]

    def test_adapter_imports_without_error(self):
        from adapters.probe_openhands import init_openhands_probe

        self.assertTrue(callable(init_openhands_probe))

    def test_monkey_patch_applies_to_step(self):
        from adapters.probe_openhands import init_openhands_probe

        probe = init_openhands_probe()
        from openhands.controller.agent_controller import AgentController

        self.assertNotEqual(AgentController.step.__name__, "step")

    def test_monkey_patch_applies_to_completion(self):
        from adapters.probe_openhands import init_openhands_probe

        probe = init_openhands_probe()
        from openhands.llm.llm import LLM

        self.assertNotEqual(LLM.completion.__name__, "completion")

    def test_emit_on_step(self):
        from adapters.probe_openhands import init_openhands_probe

        probe = init_openhands_probe()
        from openhands.controller.agent_controller import AgentController

        ctrl = AgentController()
        ctrl.step()
        events = [
            e
            for e in _captured_events
            if e["event_type"] in ("agent_step_start", "agent_step")
        ]
        self.assertTrue(len(events) > 0)
        self.assertIn("agent_name", events[0]["payload"].get("layer_agent", {}))

    def test_emit_on_llm_invoke(self):
        from adapters.probe_openhands import init_openhands_probe

        probe = init_openhands_probe()
        from openhands.llm.llm import LLM

        llm = LLM()
        llm.completion()
        events = [e for e in _captured_events if e["event_type"] == "llm_invoke"]
        self.assertTrue(len(events) > 0)
        self.assertIn("layer_llm", events[0]["payload"])


if __name__ == "__main__":
    unittest.main()
