# _auto.py —— 乾坤镜 LangChain 自动激活模块
# 通过 .pth 文件注册 PEP 302 import hook，
# 在 langchain_core 首次导入时自动 monkey-patch

import sys


class _MingLangChainAutoPatch:
    _patched = False

    def find_spec(self, fullname, path, target=None):
        if not self._patched and (
            fullname == "langchain_core"
            or fullname.startswith("langchain_core.")
            or fullname == "langchain"
        ):
            self._apply_patch()
        return None

    @classmethod
    def _apply_patch(cls):
        if cls._patched:
            return
        cls._patched = True
        try:
            from ming_probe_langchain.probe_langchain import init_langchain_probe

            init_langchain_probe(system="langchain", mode="white")
        except Exception:
            pass
        finally:
            try:
                sys.meta_path = [m for m in sys.meta_path if not isinstance(m, cls)]
            except Exception:
                pass


sys.meta_path.insert(0, _MingLangChainAutoPatch())
