# ming_probe_langchain —— 乾坤镜 LangChain 自动探针
# pip install 即自动激活，零代码改动

from .probe_langchain import init_langchain_probe

__all__ = ["init_langchain_probe"]
__version__ = "0.11.9"
