# ming-probe-langchain

乾坤镜（Mingjing）LangChain 自动探针。

**pip install 即自动激活**，零代码改动。安装后所有 LangChain 调用（LLM invoke、tool call、retriever、stream、batch）自动被乾坤镜捕获，写入热轨供诊断分析。

## 安装

```bash
pip install ming-probe-langchain
```

**不用 import、不用改代码、不用设 callback**。装完即生效。

## 原理

通过 PEP 302 import hook，在 `langchain_core` 首次导入时自动注册 monkey-patch 和 BaseCallbackHandler，覆盖：

- `ChatModel` / `LLM` → `invoke`、`stream`、`batch`
- `BaseTool` → `invoke`
- `BaseRetriever` → `invoke`
- `RunnableSequence` → `invoke`
- 逐 token 输出 → `on_llm_new_token`
- 错误事件 → `on_llm_error`、`on_tool_error`

## 前置条件

需要乾坤镜归档器（archiver）在后台运行，消费热轨数据。单独安装：

```bash
# 方式1：完整乾坤镜
pip install ming

# 方式2：仅归档器（轻量）
# 见 https://github.com/mingjing-probe/ming
```

## 手动初始化（可选）

如需手动控制初始化时机，而非自动激活：

```python
from ming_probe_langchain import init_langchain_probe
probe = init_langchain_probe(system='my_app', mode='white')
```

## 诊断容量

基于 LangChain 发射的 11 类事件（llm_invoke、llm_output、tool_call、memory_retrieve、agent_step、error、stream_token、chat_model_start、cache_hit、relevance_scores、chunk），可从 159 条规则库中匹配约 **100 条**可用规则。

不同适配器因事件类型覆盖面不同，容量不同（如 Vercel AI SDK 仅 2 类事件 → ~13 条规则）。

## 兼容性

- `langchain-core >= 1.0`（含 langchain >= 0.3）
- Python >= 3.10
- 零第三方依赖（仅需 Python 标准库）
